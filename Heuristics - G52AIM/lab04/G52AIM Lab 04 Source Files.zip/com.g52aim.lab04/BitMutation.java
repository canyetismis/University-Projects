package com.g52aim.lab04;

import java.util.Random;

import g52aim.domains.chesc2014_SAT.SAT;
import g52aim.satheuristics.genetics.PopulationHeuristic;

/**
 * Bit Mutation for performing Genetic Mutation of solutions
 * @author Warren G. Jackson
 *
 */
public class BitMutation extends PopulationHeuristic {

	private final double MUTATION_RATE;
	
	public BitMutation(SAT problem, Random random) {
		
		super(problem, random);
		this.MUTATION_RATE = 0.0d; // TODO set mutation rate in accordance with bit mutation definition.
	}

	/*
	 * PSEUDOCODE
	 *
	 * INPUT: s
     * FOR 0 -> chromosome_length
     *     IF random < 1 / chromosome_length THEN
     *         bitFlip(s,j) // flip the jth bit of solution s
     *      ENDIF
     * ENDFOR
	 */
	public void applyHeuristic(int solutionIndex) {

		// TODO implementation of bit mutation
	}
}
